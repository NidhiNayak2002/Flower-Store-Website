<?php

$conn = mysqli_connect('localhost','root','','shop_db') or die('connection failed');


/*$conn = mysqli_connect('localhost','root','','shop_db');
if($conn==false)
{
    die("Error:could not connect".mysqli_connect_error());
}
echo"connected successfully";
*/

?>
